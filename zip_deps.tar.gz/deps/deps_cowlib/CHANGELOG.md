CHANGELOG
=========

1.0.1
-----

 *  Multipart: no line break after close delimiter

1.0.0
-----

 *  Initial release.
